ids = [("1_baseline_tanh_mlp", "tanh MLP"),
       ("1_baseline_relu_mlp", "relu MLP"),
       ("1_baseline_sine_mlp", "sine MLP"),
       ("1_baseline_tanh_mlp_pos", "tanh MLP Positional"),
       ("1_baseline_tanh_mlp_gaussian", "tanh MLP Gaussian"),
       ("1_baseline_tanh_mlp_es", "tanh MLP ES"),
       ("1_baseline_relu_mlp_pos", "relu MLP Positional"),
       ("1_baseline_relu_mlp_gaussian", "relu MLP Gaussian"),
       ("1_baseline_relu_mlp_es", "relu MLP ES")
    #    ("1_baseline_sine_mlp_pos", "sine MLP Positional"),
    #    ("1_baseline_sine_mlp_gaussian", "sine MLP Gaussian"),
    #    ("1_baseline_sine_mlp_es", "sine MLP ES")
       ]

ids = [("1_baseline_tanh_mod_mlp_nofeat", "tanh Mod-MLP"),
       ("1_baseline_relu_mod_mlp_nofeat", "relu Mod-MLP"),
       ("1_baseline_sine_mod_mlp_nofeat", "sine Mod-MLP"),
       ("1_baseline_tanh_mod_mlp_pos", "tanh Mod-MLP Positional"),
       ("1_baseline_tanh_mod_mlp_gaussian", "tanh Mod-MLP Gaussian"),
       ("1_baseline_tanh_mod_mlp_es", "tanh Mod-MLP ES"),
       ("1_baseline_relu_mod_mlp_pos", "relu Mod-MLP Positional"),
       ("1_baseline_relu_mod_mlp_gaussian", "relu Mod-MLP Gaussian"),
       ("1_baseline_relu_mod_mlp_es", "relu Mod-MLP ES"),
       ("1_baseline_sine_mod_mlp_pos", "sine Mod-MLP Positional"),
       # ("1_baseline_sine_mod_mlp_gaussian", "sine Mod-MLP Gaussian"),
       # ("1_baseline_sine_mod_mlp_es", "sine Mod-MLP ES")
       ]


ids = [("4_baseline_batchsize_16_100_val", "BS 16/100"),
       ("4_baseline_batchsize_16_200_val", "BS 16/200"),
       ("4_baseline_batchsize_16_400_val", "BS 16/400"),
       ("4_baseline_batchsize_16_800_val", "BS 16/800"),
       ("4_baseline_batchsize_32_100_val", "BS 32/100"),
       ("4_baseline_batchsize_32_200_val", "BS 32/200"),
       ("4_baseline_batchsize_32_400_val", "BS 32/400"),
       ("4_baseline_batchsize_32_800_val", "BS 32/800"),
       ("4_baseline_batchsize_64_100_val", "BS 64/100"),
       ("4_baseline_batchsize_64_200_val", "BS 64/200"),
       ("4_baseline_batchsize_64_400_val", "BS 64/400"),
       ("4_baseline_batchsize_64_800_val", "BS 64/800"),
       ("4_baseline_batchsize_96_100_val", "BS 96/100"),
       ("4_baseline_batchsize_96_200_val", "BS 96/200"),
       ("4_baseline_batchsize_96_400_val", "BS 96/400"),
       ("4_baseline_batchsize_96_800_val", "BS 96/800")]

ids = [("5_baseline_2_512_val", "2/512"),
       ("5_baseline_2_1024_val", "2/1024"),
       ("5_baseline_2_2048_val", "2/2048"),
       ("5_baseline_3_512_val", "3/512"),
       ("5_baseline_3_1024_val", "3/1024"),
       ("5_baseline_3_2048_val", "3/2048"),
       ("5_baseline_4_512_val", "4/512"),
       ("5_baseline_4_1024_val", "4/1024"),
       ("5_baseline_4_2048_val", "4/2048"),
       ("5_baseline_5_512_val", "5/512"),
       ("5_baseline_5_1024_val", "5/1024"),
       ("5_baseline_5_2048_val", "5/2048")]

ids = [("6_baseline_bn2_tn2_val", "BN=2PPW TN=2PPW"),
       ("6_baseline_bn2_tn4_val", "BN=2PPW TN=4PPW"),
       ("6_baseline_bn2_tn6_val", "BN=2PPW TN=6PPW"),
       ("6_baseline_bn4_tn2_val", "BN=4PPW TN=2PPW"),
       ("6_baseline_bn4_tn4_val", "BN=4PPW TN=4PPW"),
       ("6_baseline_bn4_tn6_val", "BN=4PPW TN=6PPW")]

ids = [("7_dxu2_dx6_dt2_srcdx2_val", "dx_src=2 dx=6PPW, dt=2PPW"),
       ("7_dxu2_dx6_dt2_srcdx3_val", "dx_src=3 dx=6PPW, dt=2PPW"),
       ("7_dxu2_dx6_dt2_srcdx4_val", "dx_src=4 dx=6PPW, dt=2PPW"),
       ("7_dxu2_dx6_dt2_srcdx5_val", "dx_src=5 dx=6PPW, dt=2PPW"),
       ("7_dxu2_dx6_dt2_srcdx6_val", "dx_src=6 dx=6PPW, dt=2PPW"),
       ("7_dxu2_dx4_dt2_srcdx6_val", "dx_src=6 dx=4PPW, dt=2PPW"),
       ("7_dxu2_dx6_dt4_srcdx6val", "dx_src=6 dx=6PPW, dt=4PPW")]

ids = [("7_dxu2_dx6_dt2_srcdx6_val", "FNN reference"),
       ("resnet_3333_relu_ppw2_val", "ResNet-{3,3,3,3}"),
       ("resnet_33333_relu_ppw2_val", "ResNet-{3,3,3,3,3}"),
       ("resnet_33333_relu_ppw4_val", "ResNet-{3,3,3,3,3} BN=4PPW")]